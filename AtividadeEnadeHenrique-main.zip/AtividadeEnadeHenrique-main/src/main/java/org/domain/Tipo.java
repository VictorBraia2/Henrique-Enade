package org.domain;
import java.util.List;

public class Tipo {

    public List<Categoria> carros;
    public List<Categoria> motos;
}
