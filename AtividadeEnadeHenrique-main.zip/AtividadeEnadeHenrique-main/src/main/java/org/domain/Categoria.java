package org.domain;
import java.util.List;

public class Categoria {

        public List<Veiculo> novos;
        public List<Veiculo> usados;

}
