package org.domain;

public class Veiculo {


        public int id;
        public String marca;
        public String modelo;
        public int ano;
        public double valor;

}
